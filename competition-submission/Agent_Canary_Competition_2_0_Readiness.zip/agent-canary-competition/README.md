# Agent Canary 免费竞赛构建

这是独立免费 SDK / MCP / 自检 / AI / 策略控制台构建，不是完整商业 CLI。MIT 许可保留。未包含 license、dashboard、export 或 eval 商业实现，也没有删除许可校验。

安装：npm ci；npm run build；npm test；npm run ai:console。SDK 入口 dist/sdk.js；MCP：node dist/competition.js serve --stdio。真实实验：npm run lab:agent，需要已有 Ollama/Qwen 模型；无模型也可运行界面虚拟策略与隔离演示。

人工批准：启动后端前由宿主设置 AGENT_CANARY_OPERATOR_CODE，保管独立能力码，不给模型或云端；未设置则批准不可用。

模式默认 BALANCED；写入和未审定构建需人工批准。只保护可信宿主注册到 Router 的调用，真实 symlink/进程/网络/身份边界由宿主实现。AI 不拥有执行和 Reset 权限。

普通商业包分发风险仍 OPEN；免费构建不迁移生产系统、不发布 npm、不包含客户/支付资料。所有演示危险效果为虚拟。详见 docs/RISK_POLICY.md、docs/AI_PROVIDERS.md 和竞赛仓库的第四轮证据。
