import fs from "node:fs";
import path from "node:path";
import { spawn } from "node:child_process";
import { loadConfig, type CanaryConfig } from "./config.js";
import { postJsonWebhook } from "./webhook.js";

export type EventKind =
  | "decoy_called"
  | "token_found"
  | "session_tripped"
  | "session_quarantined"
  | "credential_revocation_requested"
  | "credential_revocation_failed"
  | "action_blocked"
  | "session_reset"
  | "policy_allowed"
  | "policy_blocked"
  | "policy_approval_required"
  | "policy_approval_granted"
  | "test";

/** Risk is intentionally coarse: it is audit context, not an authorization grant. */
export type RiskLevel = "SAFE" | "READ" | "WRITE" | "NETWORK" | "EXECUTE" | "SECRET" | "DESTRUCTIVE";

export interface CanaryEvent {
  ts: string;
  kind: EventKind;
  /** Explicit event name for JSON/SIEM consumers; `kind` remains for compatibility. */
  eventType?: EventKind;
  sessionId?: string;
  reason?: string;
  toolName?: string;
  riskLevel?: RiskLevel;
  traceId?: string;
  /** Operational metadata only. Callers must never place tool arguments or secrets here. */
  metadata?: Record<string, string | number | boolean>;
  tool?: string;
  label?: string;
  path?: string;
  token?: string;
  args?: unknown;
  note?: string;
}

export interface AlertTestStatus {
  eventLog: "success" | "failure";
  desktop: "enabled" | "disabled" | "failed";
  webhook: "success" | "failed" | "not configured";
}

const MAX_EVENT_BYTES = 5 * 1024 * 1024; // ~5 MB, keeps roughly the last few thousand events
const MAX_EVENT_LINE_BYTES = 256 * 1024;
const MAX_EVENT_COUNT = 10_000;
const KEEP_LINES = 1500;
const MAX_TEXT_LENGTH = 240;
const SENSITIVE_FIELD = /(pass(word)?|secret|token|key|credential|authorization|cookie|bearer|private)/i;
const INLINE_SECRET = /(\b(?:pass(?:word)?|secret|token|api[_-]?key|credential|authorization|cookie|bearer|private[_-]?key)\b\s*[:=]\s*)(?:"[^"]*"|'[^']*'|[^\s,;]+)/gi;
const CANARY_VALUE = /\bcnry_[a-zA-Z0-9_-]+\b/g;
const EVENT_KINDS = new Set<EventKind>([
  "decoy_called", "token_found", "session_tripped", "session_quarantined",
  "credential_revocation_requested", "credential_revocation_failed",
  "action_blocked", "session_reset", "test", "policy_allowed", "policy_blocked", "policy_approval_required", "policy_approval_granted",
]);
const RISK_LEVELS = new Set<RiskLevel>(["SAFE", "READ", "WRITE", "NETWORK", "EXECUTE", "SECRET", "DESTRUCTIVE"]);

/**
 * Produce an audit-safe copy for both disk and outbound alerts.
 *
 * Tool arguments are deliberately omitted: even "harmless" arguments often
 * contain paths, URLs, or credentials that become sensitive later. Canary
 * values are also never persisted outside the local token registry.
 */
export function sanitizeEvent(ev: CanaryEvent): CanaryEvent {
  const { args: _args, ...event } = ev;
  return {
    ...event,
    ts: typeof event.ts === "string" ? safeDisplayText(event.ts, 64) : "unknown",
    kind: safeEventKind(event.kind),
    eventType: event.eventType === undefined ? undefined : safeEventKind(event.eventType),
    riskLevel: event.riskLevel === undefined || RISK_LEVELS.has(event.riskLevel) ? event.riskLevel : undefined,
    sessionId: safeText(event.sessionId, 128),
    reason: safeText(event.reason),
    toolName: safeText(event.toolName, 128),
    traceId: safeText(event.traceId, 128),
    tool: safeText(event.tool, 128),
    label: safeText(event.label, 128),
    path: safeText(event.path),
    note: safeText(event.note),
    token: event.token === undefined ? undefined : "[CANARY_REDACTED]",
    metadata: sanitizeMetadata(event.metadata),
  };
}

function safeEventKind(value: unknown): EventKind {
  return typeof value === "string" && EVENT_KINDS.has(value as EventKind) ? value as EventKind : "test";
}

function sanitizeMetadata(metadata: CanaryEvent["metadata"]): CanaryEvent["metadata"] {
  if (!metadata) return undefined;
  const safe: NonNullable<CanaryEvent["metadata"]> = {};
  for (const [key, value] of Object.entries(metadata).slice(0, 16)) {
    const safeKey = key.replace(/[\u0000-\u001f\u007f-\u009f\u2028\u2029]/g, " ").slice(0, 80);
    safe[safeKey] = SENSITIVE_FIELD.test(key) ? "[REDACTED]" : typeof value === "string" ? redactText(value) : value;
  }
  return Object.keys(safe).length ? safe : undefined;
}

function safeText(value: string | undefined, maxLength = MAX_TEXT_LENGTH): string | undefined {
  return value === undefined ? undefined : safeDisplayText(value, maxLength);
}

/** Sanitize untrusted text before printing it to a terminal or log line. */
export function safeDisplayText(value: string, maxLength = MAX_TEXT_LENGTH): string {
  return redactText(String(value ?? ""), maxLength);
}

function redactText(value: string, maxLength = MAX_TEXT_LENGTH): string {
  return value
    .replace(/[\u0000-\u001f\u007f-\u009f\u2028\u2029]/g, " ")
    .replace(CANARY_VALUE, "[CANARY_REDACTED]")
    .replace(INLINE_SECRET, "$1[REDACTED]")
    .slice(0, maxLength);
}

export function logEvent(ev: CanaryEvent, eventsFile?: string): void {
  const file = eventsFile ?? loadConfig().eventsFile;
  fs.mkdirSync(path.dirname(file), { recursive: true });
  // retention: rotate when the audit log grows past the cap (keep recent lines)
  try {
    if (fs.existsSync(file) && fs.statSync(file).size > MAX_EVENT_BYTES) {
      const lines = readBoundedTail(file, MAX_EVENT_BYTES).trim().split("\n");
      fs.writeFileSync(file, lines.slice(-KEEP_LINES).join("\n") + "\n");
    }
  } catch {
    /* rotation is best-effort */
  }
  fs.appendFileSync(file, JSON.stringify(sanitizeEvent(ev)) + "\n", { encoding: "utf8", mode: 0o600 });
}

export function readEvents(eventsFile?: string, tail = 100): CanaryEvent[] {
  const file = eventsFile ?? loadConfig().eventsFile;
  let raw: string;
  try {
    raw = readBoundedTail(file, MAX_EVENT_BYTES);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return [];
    throw new Error("Could not read the event log; the report may be incomplete.", { cause: error });
  }

  const requested = Number.isFinite(tail) ? Math.max(0, Math.floor(tail)) : MAX_EVENT_COUNT;
  const maxEvents = Math.min(requested, MAX_EVENT_COUNT);
  if (maxEvents === 0) return [];
  const events: CanaryEvent[] = [];
  for (const line of raw.split("\n")) {
    if (!line.trim()) continue;
    if (Buffer.byteLength(line, "utf8") > MAX_EVENT_LINE_BYTES) continue;
    try {
      // Older installations may contain events written before centralized
      // redaction. Sanitize on read so reports and dashboards never replay
      // stale raw arguments or canary values.
      events.push(sanitizeEvent(JSON.parse(line) as CanaryEvent));
    } catch {
      /* skip corrupted lines */
    }
  }
  return events.slice(-maxEvents);
}

/** Read at most `limit` bytes from the end of a JSONL file and drop a partial first line. */
function readBoundedTail(file: string, limit: number): string {
  const descriptor = fs.openSync(file, fs.constants.O_RDONLY);
  try {
    const size = fs.fstatSync(descriptor).size;
    const length = Math.min(size, limit);
    if (!length) return "";
    const buffer = Buffer.allocUnsafe(length);
    let offset = 0;
    const position = size - length;
    while (offset < length) {
      const count = fs.readSync(descriptor, buffer, offset, length - offset, position + offset);
      if (count === 0) break;
      offset += count;
    }
    let start = 0;
    if (position > 0) {
      const newline = buffer.indexOf(0x0a);
      start = newline < 0 ? offset : newline + 1;
    }
    return buffer.toString("utf8", start, offset);
  } finally {
    fs.closeSync(descriptor);
  }
}

/**
 * Fan an event out to every configured channel. Fire-and-forget by design:
 * alerts must never break the decoy's fake response, and a slow webhook must
 * never stall the MCP stdio loop.
 */
export function fireAlerts(ev: CanaryEvent, cfg: CanaryConfig = loadConfig()): void {
  const safeEvent = sanitizeEvent(ev);
  if (cfg.webhook) void postWebhook(cfg.webhook, safeEvent);
  if (cfg.notify) void notifyDesktop(summarize(safeEvent));
}

/** Awaitable status path for the CLI's explicit alert-test command. */
export async function sendAlertTest(
  ev: CanaryEvent,
  cfg: CanaryConfig = loadConfig()
): Promise<AlertTestStatus> {
  const safeEvent = sanitizeEvent(ev);
  let eventLog: AlertTestStatus["eventLog"] = "success";
  try {
    logEvent(safeEvent, cfg.eventsFile);
  } catch {
    eventLog = "failure";
  }

  const webhookPromise = cfg.webhook
    ? postWebhook(cfg.webhook, safeEvent)
    : Promise.resolve<boolean | null>(null);
  const desktopPromise = cfg.notify
    ? notifyDesktop(summarize(safeEvent))
    : Promise.resolve<boolean | null>(null);
  const [webhookDelivered, desktopLaunched] = await Promise.all([webhookPromise, desktopPromise]);

  return {
    eventLog,
    desktop: !cfg.notify ? "disabled" : desktopLaunched ? "enabled" : "failed",
    webhook:
      webhookDelivered === null ? "not configured" : webhookDelivered ? "success" : "failed",
  };
}

function summarize(ev: CanaryEvent): string {
  if (ev.kind === "decoy_called") return `Compromise signal: decoy tool "${ev.tool}" was invoked.`;
  if (ev.kind === "token_found") return `Canary token "${ev.label}" surfaced in ${ev.path ?? "output"}.`;
  if (ev.kind === "session_tripped") return `Session ${ev.sessionId ?? "unknown"} tripped: ${ev.reason ?? "compromise signal"}.`;
  if (ev.kind === "session_quarantined") return `Session ${ev.sessionId ?? "unknown"} is quarantined.`;
  if (ev.kind === "credential_revocation_requested") return `Credential revocation was requested for session ${ev.sessionId ?? "unknown"}.`;
  if (ev.kind === "credential_revocation_failed") return `Credential revocation adapter failed for session ${ev.sessionId ?? "unknown"}.`;
  if (ev.kind === "action_blocked") return `Blocked ${ev.toolName ?? ev.tool ?? "tool"} in quarantined session.`;
  if (ev.kind === "session_reset") return `Session ${ev.sessionId ?? "unknown"} was manually reset.`;
  return `Test alert from agent-canary.`;
}

async function postWebhook(url: string, ev: CanaryEvent): Promise<boolean> {
  return postJsonWebhook(url, ev);
}

function psEscape(s: string): string {
  return s.replace(/'/g, "''");
}

async function notifyDesktop(body: string): Promise<boolean> {
  const launched = (child: ReturnType<typeof spawn>): Promise<boolean> =>
    new Promise((resolve) => {
      let settled = false;
      const finish = (value: boolean) => {
        if (settled) return;
        settled = true;
        resolve(value);
      };
      child.once("spawn", () => finish(true));
      child.once("error", () => finish(false));
    });

  try {
    const platform = process.platform;
    if (platform === "win32") {
      const script =
        `Add-Type -AssemblyName System.Windows.Forms; ` +
        `$n = New-Object System.Windows.Forms.NotifyIcon; ` +
        `$n.Visible = $true; ` +
        `$n.ShowBalloonTip(8000, 'Agent Canary', '${psEscape(body)}', 'Warning'); ` +
        `Start-Sleep -Seconds 9; $n.Dispose()`;
      const child = spawn("powershell", ["-NoProfile", "-Command", script], { stdio: "ignore", detached: true });
      const notification = launched(child);
      child.unref();
      return await notification;
    } else if (platform === "darwin") {
      const quoted = body.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
      const child = spawn("osascript", ["-e", `display notification "${quoted}" with title "Agent Canary"`], {
        stdio: "ignore",
        detached: true,
      });
      const notification = launched(child);
      child.unref();
      return await notification;
    } else {
      // notify-send may not exist on headless systems; the error listener swallows ENOENT.
      const child = spawn("notify-send", ["Agent Canary", body], { stdio: "ignore", detached: true });
      const notification = launched(child);
      child.unref();
      return await notification;
    }
  } catch {
    /* desktop notifications are optional */
    return false;
  }
}
