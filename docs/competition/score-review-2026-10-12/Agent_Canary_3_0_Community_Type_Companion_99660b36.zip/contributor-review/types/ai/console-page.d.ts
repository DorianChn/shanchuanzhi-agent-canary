/** Self-contained local UI, reusing the existing experiment viewer's palette.
 * No CDN, frontend key storage, or external assets. */
export declare const CONSOLE_PAGE: string;
