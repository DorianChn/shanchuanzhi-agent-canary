import type { Command } from 'commander';
export declare function registerAICommands(program: Command): void;
