import http from 'node:http';
export declare function startAIConsole(options?: {
    port?: number;
    apiKey?: string;
    keyOrigin?: string;
    eventsFile?: string;
    operatorApprovalCode?: string;
    preReviewTimeoutMs?: number;
}): Promise<{
    url: string;
    server: http.Server<typeof http.IncomingMessage, typeof http.ServerResponse>;
    close: () => Promise<void>;
}>;
