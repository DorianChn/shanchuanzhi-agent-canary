import { type ProtectionMode } from '../risk-policy.js';
import type { AIProvider } from './types.js';
/** Console-only virtual executors. No shell/file/network side effects. */
export declare function createPolicySandbox(options?: {
    reviewTimeoutMs?: number;
}): {
    state: () => {
        mode: ProtectionMode;
        guardState: import("../containment.js").CircuitState;
        callbacks: number;
        pending: {
            requestId: string;
            tool: string;
            risks: import("../risk-policy.js").ToolRisk[];
            reason: string;
            expiresAt: number;
        }[];
        events: import("../alerts.js").CanaryEvent[];
        dataflow: {
            label: string;
            expires: number;
            hash: string;
        }[];
        reviews: {
            tool: string;
            result: import("./types.js").SecurityAnalysisResult | null;
            status: string;
            durationMs: number;
        }[];
        reviewEnabled: boolean;
        scope: string;
    };
    setReview(enabled: boolean, nextProvider: AIProvider): {
        mode: ProtectionMode;
        guardState: import("../containment.js").CircuitState;
        callbacks: number;
        pending: {
            requestId: string;
            tool: string;
            risks: import("../risk-policy.js").ToolRisk[];
            reason: string;
            expiresAt: number;
        }[];
        events: import("../alerts.js").CanaryEvent[];
        dataflow: {
            label: string;
            expires: number;
            hash: string;
        }[];
        reviews: {
            tool: string;
            result: import("./types.js").SecurityAnalysisResult | null;
            status: string;
            durationMs: number;
        }[];
        reviewEnabled: boolean;
        scope: string;
    };
    setMode(next: ProtectionMode): {
        mode: ProtectionMode;
        guardState: import("../containment.js").CircuitState;
        callbacks: number;
        pending: {
            requestId: string;
            tool: string;
            risks: import("../risk-policy.js").ToolRisk[];
            reason: string;
            expiresAt: number;
        }[];
        events: import("../alerts.js").CanaryEvent[];
        dataflow: {
            label: string;
            expires: number;
            hash: string;
        }[];
        reviews: {
            tool: string;
            result: import("./types.js").SecurityAnalysisResult | null;
            status: string;
            durationMs: number;
        }[];
        reviewEnabled: boolean;
        scope: string;
    };
    action(action: string): Promise<{
        mode: ProtectionMode;
        guardState: import("../containment.js").CircuitState;
        callbacks: number;
        pending: {
            requestId: string;
            tool: string;
            risks: import("../risk-policy.js").ToolRisk[];
            reason: string;
            expiresAt: number;
        }[];
        events: import("../alerts.js").CanaryEvent[];
        dataflow: {
            label: string;
            expires: number;
            hash: string;
        }[];
        reviews: {
            tool: string;
            result: import("./types.js").SecurityAnalysisResult | null;
            status: string;
            durationMs: number;
        }[];
        reviewEnabled: boolean;
        scope: string;
        status: string;
        result: unknown;
    } | {
        mode: ProtectionMode;
        guardState: import("../containment.js").CircuitState;
        callbacks: number;
        pending: {
            requestId: string;
            tool: string;
            risks: import("../risk-policy.js").ToolRisk[];
            reason: string;
            expiresAt: number;
        }[];
        events: import("../alerts.js").CanaryEvent[];
        dataflow: {
            label: string;
            expires: number;
            hash: string;
        }[];
        reviews: {
            tool: string;
            result: import("./types.js").SecurityAnalysisResult | null;
            status: string;
            durationMs: number;
        }[];
        reviewEnabled: boolean;
        scope: string;
        status: "DENY" | "ALLOW" | "APPROVAL_REQUIRED";
        decision: import("../risk-policy.js").PolicyDecision;
    } | {
        mode: ProtectionMode;
        guardState: import("../containment.js").CircuitState;
        callbacks: number;
        pending: {
            requestId: string;
            tool: string;
            risks: import("../risk-policy.js").ToolRisk[];
            reason: string;
            expiresAt: number;
        }[];
        events: import("../alerts.js").CanaryEvent[];
        dataflow: {
            label: string;
            expires: number;
            hash: string;
        }[];
        reviews: {
            tool: string;
            result: import("./types.js").SecurityAnalysisResult | null;
            status: string;
            durationMs: number;
        }[];
        reviewEnabled: boolean;
        scope: string;
        status: string;
        decision: import("../containment.js").ToolDecision;
    }>;
    approve(id: string): Promise<{
        mode: ProtectionMode;
        guardState: import("../containment.js").CircuitState;
        callbacks: number;
        pending: {
            requestId: string;
            tool: string;
            risks: import("../risk-policy.js").ToolRisk[];
            reason: string;
            expiresAt: number;
        }[];
        events: import("../alerts.js").CanaryEvent[];
        dataflow: {
            label: string;
            expires: number;
            hash: string;
        }[];
        reviews: {
            tool: string;
            result: import("./types.js").SecurityAnalysisResult | null;
            status: string;
            durationMs: number;
        }[];
        reviewEnabled: boolean;
        scope: string;
        status: string;
        result: unknown;
    } | {
        mode: ProtectionMode;
        guardState: import("../containment.js").CircuitState;
        callbacks: number;
        pending: {
            requestId: string;
            tool: string;
            risks: import("../risk-policy.js").ToolRisk[];
            reason: string;
            expiresAt: number;
        }[];
        events: import("../alerts.js").CanaryEvent[];
        dataflow: {
            label: string;
            expires: number;
            hash: string;
        }[];
        reviews: {
            tool: string;
            result: import("./types.js").SecurityAnalysisResult | null;
            status: string;
            durationMs: number;
        }[];
        reviewEnabled: boolean;
        scope: string;
        status: "DENY" | "ALLOW" | "APPROVAL_REQUIRED";
        decision: import("../risk-policy.js").PolicyDecision;
    } | {
        mode: ProtectionMode;
        guardState: import("../containment.js").CircuitState;
        callbacks: number;
        pending: {
            requestId: string;
            tool: string;
            risks: import("../risk-policy.js").ToolRisk[];
            reason: string;
            expiresAt: number;
        }[];
        events: import("../alerts.js").CanaryEvent[];
        dataflow: {
            label: string;
            expires: number;
            hash: string;
        }[];
        reviews: {
            tool: string;
            result: import("./types.js").SecurityAnalysisResult | null;
            status: string;
            durationMs: number;
        }[];
        reviewEnabled: boolean;
        scope: string;
        status: string;
        decision: import("../containment.js").ToolDecision;
    }>;
    deny(id: string): {
        mode: ProtectionMode;
        guardState: import("../containment.js").CircuitState;
        callbacks: number;
        pending: {
            requestId: string;
            tool: string;
            risks: import("../risk-policy.js").ToolRisk[];
            reason: string;
            expiresAt: number;
        }[];
        events: import("../alerts.js").CanaryEvent[];
        dataflow: {
            label: string;
            expires: number;
            hash: string;
        }[];
        reviews: {
            tool: string;
            result: import("./types.js").SecurityAnalysisResult | null;
            status: string;
            durationMs: number;
        }[];
        reviewEnabled: boolean;
        scope: string;
    };
    close(): void;
};
