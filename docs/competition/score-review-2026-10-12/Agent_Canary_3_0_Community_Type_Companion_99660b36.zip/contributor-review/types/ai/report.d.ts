import type { SecurityAnalysisResult } from './types.js';
export declare function renderAIReport(results: SecurityAnalysisResult[], format: 'json' | 'markdown' | 'csv'): string;
