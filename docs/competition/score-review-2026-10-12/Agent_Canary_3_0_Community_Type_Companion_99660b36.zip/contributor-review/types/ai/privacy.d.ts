import type { SecurityEvidence } from './types.js';
/** Best-effort minimization, not DLP certification. Preview before cloud consent. */
export declare function redactAnalysisText(input: string, secrets?: string[]): string;
export declare function previewAnalysis(events: SecurityEvidence[], secrets?: string[]): SecurityEvidence[];
/** Preserve field values and explicit IDs while avoiding JSON-escape-heavy model quotes. */
export declare function formatAnalysisEvent(event: Record<string, unknown>): string;
