import type { AIProvider, ProviderConfig, SecurityAnalysisResult, SecurityEvidence } from './types.js';
export * from './types.js';
export { previewAnalysis, redactAnalysisText, formatAnalysisEvent } from './privacy.js';
export declare function validateAnalysisOutput(raw: string, events: SecurityEvidence[]): Pick<SecurityAnalysisResult, 'verdict' | 'severity' | 'confidence' | 'summary' | 'evidence' | 'reasoningSummary' | 'recommendedActions'>;
export declare function createAIProvider(input: ProviderConfig): AIProvider;
