import type { ProviderConfig } from './types.js';
export declare class AITransportError extends Error {
    readonly code: string;
    readonly retryable: boolean;
    constructor(code: string, retryable?: boolean);
}
export declare function validateAIEndpoint(config: Pick<ProviderConfig, 'baseUrl' | 'kind'>): URL;
/** DNS checked once and pinned to the socket; no redirects, bounded response. */
export declare function requestAIJson(config: ProviderConfig, suffix: string, body: unknown, signal: AbortSignal): Promise<any>;
