/** Deterministic sandbox demonstration, NOT a model-selected attack. */
export declare function runAdvisoryDemo(): Promise<{
    mode: string;
    state: import("../containment.js").CircuitState;
    normalCallbacks: number;
    dangerousCallbacks: number;
    blocked: boolean;
    events: import("../alerts.js").CanaryEvent[];
}>;
