/** Bounded fingerprints for exact/encoded/split fragments. Not complete dynamic taint. */
export declare class DataFlowTracker {
    readonly ttlMs: number;
    readonly limit: number;
    private readonly key;
    private readonly tags;
    constructor(ttlMs?: number, limit?: number);
    private digest;
    private sweep;
    register(sourceId: string, value: string): void;
    inspect(value: string): string[];
    snapshot(): {
        sourceId: string;
        expires: number;
        digest: string;
    }[];
}
