/** Real gateway and real temporary file IO, explicitly DEMO; no model behavior fabricated. */
export declare function createRuntimeDemo(): {
    state: () => {
        mode: string;
        agent: string;
        coverage: string;
        guard: import("../containment.js").CircuitState;
        decoys: {
            id: string;
            kind: import("./honeypot.js").DecoyKind;
            path: string;
        }[];
        interactions: {
            eventId: string;
            decoyId: string;
            sessionId: string;
            kind: import("./honeypot.js").DecoyInteraction;
            timestamp: string;
        }[];
        evidence: import("./evidence.js").SecurityEvidenceEvent[];
        chain: {
            valid: boolean;
            reason: string;
            head: string | null;
        };
        pending: {
            requestId: string;
            tool: string;
            expiresAt: number;
        }[];
        dataflow: {
            sourceId: string;
            expires: number;
            digest: string;
        }[];
    };
    action(name: string): Promise<{
        lastResult: unknown;
        mode: string;
        agent: string;
        coverage: string;
        guard: import("../containment.js").CircuitState;
        decoys: {
            id: string;
            kind: import("./honeypot.js").DecoyKind;
            path: string;
        }[];
        interactions: {
            eventId: string;
            decoyId: string;
            sessionId: string;
            kind: import("./honeypot.js").DecoyInteraction;
            timestamp: string;
        }[];
        evidence: import("./evidence.js").SecurityEvidenceEvent[];
        chain: {
            valid: boolean;
            reason: string;
            head: string | null;
        };
        pending: {
            requestId: string;
            tool: string;
            expiresAt: number;
        }[];
        dataflow: {
            sourceId: string;
            expires: number;
            digest: string;
        }[];
    }>;
    approve(id: string): Promise<{
        lastResult: unknown;
        mode: string;
        agent: string;
        coverage: string;
        guard: import("../containment.js").CircuitState;
        decoys: {
            id: string;
            kind: import("./honeypot.js").DecoyKind;
            path: string;
        }[];
        interactions: {
            eventId: string;
            decoyId: string;
            sessionId: string;
            kind: import("./honeypot.js").DecoyInteraction;
            timestamp: string;
        }[];
        evidence: import("./evidence.js").SecurityEvidenceEvent[];
        chain: {
            valid: boolean;
            reason: string;
            head: string | null;
        };
        pending: {
            requestId: string;
            tool: string;
            expiresAt: number;
        }[];
        dataflow: {
            sourceId: string;
            expires: number;
            digest: string;
        }[];
    }>;
    close(): Promise<void>;
};
