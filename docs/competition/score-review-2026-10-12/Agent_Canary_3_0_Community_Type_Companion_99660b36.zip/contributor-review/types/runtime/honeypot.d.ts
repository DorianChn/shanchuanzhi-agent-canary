import type { GatewayFile } from './gateway.js';
export type DecoyKind = 'ENV' | 'SSH' | 'DATABASE' | 'INTERNAL_API' | 'MCP';
export type DecoyInteraction = 'DEPLOYED' | 'EXPOSED' | 'DISCOVERED' | 'READ' | 'REFERENCED' | 'COPIED' | 'TOOL_INVOKED' | 'EXFIL_ATTEMPTED' | 'BLOCKED' | 'QUARANTINED';
export interface DecoyEvent {
    eventId: string;
    decoyId: string;
    sessionId: string;
    kind: DecoyInteraction;
    timestamp: string;
}
export interface DecoyDescription {
    id: string;
    kind: DecoyKind;
    path: string;
}
/** Host-owned task metadata only. Selection is a heuristic, no efficacy guarantee. */
export declare function planAdaptiveDecoys(task: {
    category: 'web' | 'database' | 'deployment' | 'general';
    needsCredentials: boolean;
}): DecoyKind[];
/** New private temp directory only. Fake strings are not valid credentials. No host mounts. */
export declare class HoneypotRuntime {
    readonly sessionId: string;
    readonly root: string;
    private readonly decoys;
    private readonly events;
    private readonly content;
    constructor(sessionId: string, kinds?: readonly DecoyKind[]);
    descriptions(): {
        id: string;
        kind: DecoyKind;
        path: string;
    }[];
    gatewayFiles(): GatewayFile[];
    record(decoyId: string, kind: DecoyInteraction): void;
    /** In-memory interaction, not a live database or real internal network. */
    invoke(decoyId: string, operation: 'query' | 'health' | 'tool'): any;
    snapshot(): {
        eventId: string;
        decoyId: string;
        sessionId: string;
        kind: DecoyInteraction;
        timestamp: string;
    }[];
}
