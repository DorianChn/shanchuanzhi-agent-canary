import type { AgentGuard, ToolCall } from '../containment.js';
import type { AIProvider } from '../ai/types.js';
import { EvidenceRecorder, type EvidenceDecision } from './evidence.js';
export interface GatewayFile {
    path: string;
    writable?: boolean;
    approvalRequired?: boolean;
    sensitive?: boolean;
    decoyId?: string;
}
export interface GatewayCommand {
    executable: string;
    args: readonly string[];
    approvalRequired?: boolean;
}
export interface GatewayOptions {
    agentId: string;
    guard: AgentGuard;
    workspaceRoot: string;
    files: readonly GatewayFile[];
    commands?: Record<string, GatewayCommand>;
    readOrigins?: readonly string[];
    evidence: EvidenceRecorder;
    provider?: AIProvider;
    cloudConsent?: boolean;
    timeoutMs?: number;
    reviewTimeoutMs?: number;
    approvalTtlMs?: number;
    onDecoyRead?: (decoyId: string) => void;
    /** Host-owned MCP callback only. Capabilities are keyed by exact trusted tool ID. */
    mcpTools?: Record<string, {
        execute: (args: Record<string, unknown>, signal: AbortSignal) => Promise<unknown>;
        approvalRequired: boolean;
        risk?: 'READ_ONLY' | 'WRITE' | 'EXECUTE' | 'NETWORK' | 'SENSITIVE_DATA' | 'DESTRUCTIVE';
    }>;
}
export declare class GatewayDeniedError extends Error {
    readonly reason: string;
    readonly requestId: string;
    readonly decision: EvidenceDecision;
    constructor(reason: string, requestId: string, decision?: EvidenceDecision);
}
/** Capability-bound host runtime. No model-facing reset, approval or resource registration. */
export declare function createTrustedExecutionGateway(options: GatewayOptions): Readonly<{
    agent: Readonly<{
        dispatch(call: ToolCall, signal?: AbortSignal): Promise<unknown>;
    }>;
    operator: Readonly<{
        pending(): {
            requestId: string;
            tool: string;
            expiresAt: number;
        }[];
        approve(requestId: string): Promise<unknown>;
        reject(requestId: string): never;
    }>;
    evidence: () => import("./evidence.js").SecurityEvidenceEvent[];
    dataflow: () => {
        label: string;
        expires: number;
        hash: string;
    }[];
    provenance: () => {
        sourceId: string;
        expires: number;
        digest: string;
    }[];
    close(): Promise<void>;
}>;
