export declare const EVIDENCE_VERSION: "0.1";
export type EvidenceDecision = 'ALLOW' | 'DENY' | 'REQUIRE_APPROVAL' | 'SANDBOX' | 'OBSERVE_ONLY';
export type ExecutionStatus = 'NOT_STARTED' | 'RUNNING' | 'SUCCEEDED' | 'FAILED' | 'CANCELLED';
export type SideEffectVerification = 'NOT_STARTED' | 'VERIFIED' | 'NOT_VERIFIED' | 'FAILED';
export interface SecurityEvidenceEvent {
    schema_version: '0.1';
    evidence_id: string;
    session_id: string;
    agent_id: string;
    tool_id: string;
    request_id: string;
    request_digest: string;
    policy_version: string;
    decision: EvidenceDecision;
    decision_reason: string;
    approval_reference: string | null;
    execution_status: ExecutionStatus;
    side_effect_verification: SideEffectVerification;
    timestamp: string;
    previous_event_digest: string | null;
    event_digest: string;
}
/** Sorted UTF-16 keys, UTF-8 JSON, finite numbers, plain JSON only. Not RFC 8785. */
export declare function canonicalJSON(value: unknown): string;
export declare function evidenceDigest(value: unknown): string;
export declare function validateEvidence(event: unknown): event is SecurityEvidenceEvent;
export declare function verifyEvidenceChain(events: unknown[], expectedHead?: string): {
    valid: boolean;
    reason: string;
    head: string | null;
};
/** Single trusted writer. New file only; bounded, no silent eviction or overwrite. */
export declare class EvidenceRecorder {
    readonly maxEvents: number;
    private readonly events;
    private fd;
    private bytes;
    private closed;
    private failed;
    constructor(maxEvents?: number, file?: string);
    record(input: Omit<SecurityEvidenceEvent, 'schema_version' | 'evidence_id' | 'timestamp' | 'previous_event_digest' | 'event_digest'>): SecurityEvidenceEvent;
    snapshot(): SecurityEvidenceEvent[];
    /** Reserve intent + outcome capacity before admitting an effect. */
    canRecord(count?: number): boolean;
    close(): void;
}
