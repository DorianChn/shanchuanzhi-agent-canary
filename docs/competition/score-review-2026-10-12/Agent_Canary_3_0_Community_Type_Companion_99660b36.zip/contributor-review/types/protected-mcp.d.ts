import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { type SecurityRouterOptions } from './security-router.js';
/** Host-owned registered callbacks only. Never intercepts another server or native client tools. */
export declare function serveProtectedMCP<T>(options: SecurityRouterOptions<T> & {
    schemas: Record<string, {
        description: string;
        inputSchema: Record<string, unknown>;
    }>;
}): Promise<{
    server: Server<{
        method: string;
        params?: {
            [x: string]: unknown;
            _meta?: {
                [x: string]: unknown;
                progressToken?: string | number | undefined;
                "io.modelcontextprotocol/related-task"?: {
                    taskId: string;
                } | undefined;
            } | undefined;
        } | undefined;
    }, {
        method: string;
        params?: {
            [x: string]: unknown;
            _meta?: {
                [x: string]: unknown;
                progressToken?: string | number | undefined;
                "io.modelcontextprotocol/related-task"?: {
                    taskId: string;
                } | undefined;
            } | undefined;
        } | undefined;
    }, {
        [x: string]: unknown;
        _meta?: {
            [x: string]: unknown;
            progressToken?: string | number | undefined;
            "io.modelcontextprotocol/related-task"?: {
                taskId: string;
            } | undefined;
        } | undefined;
    }>;
    router: {
        decide(call: import("./containment.js").ToolCall): Promise<import("./security-router.js").SecurityDecision>;
        dataflow: () => {
            label: string;
            expires: number;
            hash: string;
        }[];
        reviews: () => {
            tool: string;
            result: import("./sdk.js").SecurityAnalysisResult | null;
            status: string;
            durationMs: number;
        }[];
        mode: import("./risk-policy.js").ProtectionMode;
        guard: import("./containment.js").AgentGuard;
        dispatch(call: import("./containment.js").ToolCall): Promise<{
            content: Array<{
                type: "text";
                text: string;
            }>;
            isError?: boolean;
        } | T>;
        approve(requestId: string, acknowledgedBy: string): Promise<{
            content: Array<{
                type: "text";
                text: string;
            }>;
            isError?: boolean;
        } | T>;
        pendingApprovals(): {
            requestId: string;
            tool: string;
            risks: import("./risk-policy.js").ToolRisk[];
            reason: string;
            expiresAt: number;
        }[];
        inspectPolicy(call: import("./containment.js").ToolCall): import("./risk-policy.js").PolicyDecision;
        denyApproval(requestId: string): void;
    };
}>;
