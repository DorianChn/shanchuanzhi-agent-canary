export declare const VERSION = "1.2.7";
export declare const ROOT: string;
export declare const CANARY_DIR: string;
export declare const CONFIG_PATH: string;
export declare const TOKENS_PATH: string;
export declare const EVENTS_PATH: string;
export interface CanaryConfig {
    webhook: string | null;
    notify: boolean;
    eventsFile: string;
    /** Personal Edition license server (sponsor gateway) */
    licenseServer?: string;
}
export declare function defaultConfig(): CanaryConfig;
export declare function ensureDirs(): void;
export declare function loadConfig(): CanaryConfig;
/**
 * Replace a file through a same-directory temporary file. The completed
 * temporary file is fsynced before rename so an interrupted write cannot leave
 * a partially written JSON document at the destination.
 */
export declare function writeFileAtomically(filePath: string, contents: string, mode?: number): void;
export declare function saveConfig(cfg: CanaryConfig): void;
