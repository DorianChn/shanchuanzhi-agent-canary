export type AgentClient = 'claude' | 'cursor' | 'cline' | 'codex' | 'custom';
export type IntegrationState = 'MCP_DECOY_INSTALLED' | 'GUARD_INTEGRATED' | 'VERIFIED_PROTECTED' | 'PARTIAL' | 'UNSUPPORTED';
export declare function detectAgents(home?: string): {
    agent: AgentClient;
    detected: boolean;
    status: IntegrationState;
    coverage: string;
}[];
export declare function previewAgentIntegration(agent: AgentClient, project: string, entry: {
    command: string;
    args: string[];
}): {
    agent: AgentClient;
    configPath: string;
    entry: {
        command: string;
        args: string[];
    };
    baseHash: string;
    status: IntegrationState;
    coverage: string;
    originalExisted: boolean;
};
export declare function installAgentIntegration(agent: AgentClient, project: string, entry: {
    command: string;
    args: string[];
}, expectedHash: string): {
    agent: AgentClient;
    configPath: string;
    backupPath: string;
    installedHash: string;
    originalHash: string;
    originalExisted: boolean;
    status: IntegrationState;
    coverage: string;
};
/** Restore only if the complete config is unchanged; never overwrite later user edits. */
export declare function restoreAgentIntegration(record: ReturnType<typeof installAgentIntegration>): {
    status: string;
    configPath: string;
};
