/** Bounded session-local provenance hints. Not dynamic taint analysis. */
export declare class SessionDataFlow {
    readonly ttlMs: number;
    readonly limit: number;
    private readonly key;
    private readonly entries;
    constructor(ttlMs?: number, limit?: number);
    private sweep;
    private hash;
    record(label: string, value: string): string;
    match(value: string): string | null;
    hasSensitiveSource(): boolean;
    snapshot(): {
        label: string;
        expires: number;
        hash: string;
    }[];
}
