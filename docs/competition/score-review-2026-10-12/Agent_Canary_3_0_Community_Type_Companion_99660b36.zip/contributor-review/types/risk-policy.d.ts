import { type RealToolExecutor } from './sdk.js';
import { type AgentGuard, type ToolCall } from './containment.js';
export type ProtectionMode = 'OBSERVE' | 'BALANCED' | 'STRICT';
export type ToolRisk = 'READ_ONLY' | 'WRITE' | 'EXECUTE' | 'NETWORK' | 'SENSITIVE_DATA' | 'DESTRUCTIVE';
export type ToolOperation = 'file-read' | 'file-write' | 'shell' | 'http' | 'delete' | 'sensitive-read' | 'static-read';
export interface RiskToolDescriptor {
    operation: ToolOperation;
    pathArg?: string;
    commandArg?: string;
    urlArg?: string;
    bodyArg?: string;
}
export interface RiskPolicyOptions {
    mode?: ProtectionMode;
    workspaceRoot: string;
    /** Trusted host registration; never accept these descriptors from model arguments. */
    tools: Record<string, RiskToolDescriptor>;
    /** Exact host-reviewed HTTPS origins for read-only GET requests. No wildcard. */
    allowedReadOrigins?: string[];
    eventsFile?: string;
    approvalTtlMs?: number;
    maxPending?: number;
    /** Trusted host extension; may only tighten decisions, never grant privileges. */
    reviewDecision?: (call: ToolCall, decision: Readonly<PolicyDecision>) => Promise<'DENY' | 'UNCHANGED'>;
}
export interface PolicyDecision {
    action: 'ALLOW' | 'DENY' | 'APPROVAL_REQUIRED';
    risks: ToolRisk[];
    reason: string;
    mode: ProtectionMode;
    requestId?: string;
}
export declare class PolicyBlockedError extends Error {
    readonly decision: PolicyDecision;
    constructor(decision: PolicyDecision);
}
export declare function createRiskPolicyRouter<T>(options: RiskPolicyOptions & {
    guard: AgentGuard;
    executeRealTool: RealToolExecutor<T>;
}): {
    mode: ProtectionMode;
    guard: AgentGuard;
    dispatch(call: ToolCall): Promise<{
        content: Array<{
            type: "text";
            text: string;
        }>;
        isError?: boolean;
    } | T>;
    /** HOST ONLY. Never expose this method as an Agent/MCP tool. No args token can call it. */
    approve(requestId: string, acknowledgedBy: string): Promise<{
        content: Array<{
            type: "text";
            text: string;
        }>;
        isError?: boolean;
    } | T>;
    pendingApprovals(): {
        requestId: string;
        tool: string;
        risks: ToolRisk[];
        reason: string;
        expiresAt: number;
    }[];
    inspectPolicy(call: ToolCall): PolicyDecision;
    denyApproval(requestId: string): void;
};
