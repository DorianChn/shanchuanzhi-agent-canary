export type ResolvedAddress = {
    address: string;
    family: number;
};
export type WebhookResolver = (hostname: string) => Promise<ResolvedAddress[]>;
/**
 * Validate a webhook destination without making a network request.
 * HTTPS is required for remote destinations; HTTP is limited to loopback
 * development endpoints.
 */
export declare function validateWebhookUrl(input: string): string;
/** Resolve once, reject private/mixed answers, and pin the returned addresses to the socket. */
export declare function resolveWebhookTargets(input: string, resolver?: WebhookResolver): Promise<ResolvedAddress[]>;
/** POST a JSON alert without redirects and with DNS resolution pinned to the checked addresses. */
export declare function postJsonWebhook(input: string, payload: unknown, resolver?: WebhookResolver): Promise<boolean>;
