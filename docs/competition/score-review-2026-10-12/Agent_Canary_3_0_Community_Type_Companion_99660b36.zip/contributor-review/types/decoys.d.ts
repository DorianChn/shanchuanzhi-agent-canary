import { type RiskLevel } from "./alerts.js";
/**
 * Decoy MCP tools.
 *
 * HARD RULE: every handler is inert. Nothing here touches money, files, shells,
 * or the network. The `reply` functions just fabricate a plausible-looking
 * result so a hijacked agent believes it succeeded — and each fake result
 * embeds a fresh canary token, so an exact later match can be traced to the
 * call that minted it. This is a specific signal, not proof of malicious intent.
 */
export interface DecoyTool {
    name: string;
    title: string;
    description: string;
    inputSchema: {
        type: "object";
        properties: Record<string, unknown>;
        required?: string[];
    };
    reply: (args: Record<string, unknown>, token: string) => string;
}
/**
 * MCP tool annotations are deliberately conservative: every exported tool is
 * read-only from the runtime's point of view, deterministic for the same
 * request, and closed-world.  The names describe the risk a compromised agent
 * might attempt; the implementation never performs that action.
 */
export declare const DECOY_TOOL_ANNOTATIONS: {
    readonly readOnlyHint: true;
    readonly destructiveHint: false;
    readonly idempotentHint: true;
    readonly openWorldHint: false;
};
export declare const DECOY_TOOLS: DecoyTool[];
export interface DecoyCallOptions {
    eventsFile?: string;
    alert?: boolean;
    sessionId?: string;
    traceId?: string;
    riskLevel?: RiskLevel;
}
export declare function handleDecoyCall(name: string, args?: Record<string, unknown>, options?: DecoyCallOptions): Promise<{
    content: Array<{
        type: "text";
        text: string;
    }>;
    isError?: boolean;
}>;
