import type { ToolCall } from './containment.js';
/** Optional real JSON HTTP callback: public HTTPS, checked/pinned DNS, no redirects, 256 KB cap. */
export declare function executePinnedJSONTool(call: ToolCall, context: {
    signal: AbortSignal;
}): Promise<any>;
