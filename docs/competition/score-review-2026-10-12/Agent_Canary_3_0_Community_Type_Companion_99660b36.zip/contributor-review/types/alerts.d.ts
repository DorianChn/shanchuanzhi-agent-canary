import { type CanaryConfig } from "./config.js";
export type EventKind = "decoy_called" | "token_found" | "session_tripped" | "session_quarantined" | "credential_revocation_requested" | "credential_revocation_failed" | "action_blocked" | "session_reset" | "policy_allowed" | "policy_blocked" | "policy_approval_required" | "policy_approval_granted" | "test";
/** Risk is intentionally coarse: it is audit context, not an authorization grant. */
export type RiskLevel = "SAFE" | "READ" | "WRITE" | "NETWORK" | "EXECUTE" | "SECRET" | "DESTRUCTIVE";
export interface CanaryEvent {
    ts: string;
    kind: EventKind;
    /** Explicit event name for JSON/SIEM consumers; `kind` remains for compatibility. */
    eventType?: EventKind;
    sessionId?: string;
    reason?: string;
    toolName?: string;
    riskLevel?: RiskLevel;
    traceId?: string;
    /** Operational metadata only. Callers must never place tool arguments or secrets here. */
    metadata?: Record<string, string | number | boolean>;
    tool?: string;
    label?: string;
    path?: string;
    token?: string;
    args?: unknown;
    note?: string;
}
export interface AlertTestStatus {
    eventLog: "success" | "failure";
    desktop: "enabled" | "disabled" | "failed";
    webhook: "success" | "failed" | "not configured";
}
/**
 * Produce an audit-safe copy for both disk and outbound alerts.
 *
 * Tool arguments are deliberately omitted: even "harmless" arguments often
 * contain paths, URLs, or credentials that become sensitive later. Canary
 * values are also never persisted outside the local token registry.
 */
export declare function sanitizeEvent(ev: CanaryEvent): CanaryEvent;
/** Sanitize untrusted text before printing it to a terminal or log line. */
export declare function safeDisplayText(value: string, maxLength?: number): string;
export declare function logEvent(ev: CanaryEvent, eventsFile?: string): void;
export declare function readEvents(eventsFile?: string, tail?: number): CanaryEvent[];
/**
 * Fan an event out to every configured channel. Fire-and-forget by design:
 * alerts must never break the decoy's fake response, and a slow webhook must
 * never stall the MCP stdio loop.
 */
export declare function fireAlerts(ev: CanaryEvent, cfg?: CanaryConfig): void;
/** Awaitable status path for the CLI's explicit alert-test command. */
export declare function sendAlertTest(ev: CanaryEvent, cfg?: CanaryConfig): Promise<AlertTestStatus>;
