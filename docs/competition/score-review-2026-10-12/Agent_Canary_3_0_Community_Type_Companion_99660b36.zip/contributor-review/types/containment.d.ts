import { type RiskLevel } from "./alerts.js";
import { handleDecoyCall } from "./decoys.js";
import { type CanaryToken } from "./tokens.js";
export type { RiskLevel } from "./alerts.js";
export type CircuitState = "SAFE" | "TRIPPED" | "QUARANTINED";
export interface ToolCall {
    name: string;
    args?: Record<string, unknown>;
    /** Optional correlation ID supplied by the host. It must not be a secret. */
    traceId?: string;
}
export interface TripInput {
    reason: string;
    toolName?: string;
    riskLevel?: RiskLevel;
    traceId?: string;
    /** Small, non-sensitive audit context such as a source name or rule ID. */
    metadata?: Record<string, unknown>;
}
export interface ResetRequest {
    /** A human operator identity recorded in the local audit trail. */
    acknowledgedBy: string;
    note?: string;
}
export interface ToolDecision {
    allowed: boolean;
    sessionId: string;
    state: CircuitState;
    riskLevel: RiskLevel;
    reason?: string;
    traceId?: string;
}
export interface TripResult {
    changed: boolean;
    sessionId: string;
    state: CircuitState;
    traceId: string;
}
/**
 * Minimal, secret-free context for a host's vault or broker integration.
 * The adapter should revoke session-scoped references or let their short TTL
 * expire; never pass raw credentials into the Agent Canary process.
 */
export interface CredentialRevocationRequest {
    sessionId: string;
    reason: string;
    toolName?: string;
    riskLevel: RiskLevel;
    traceId: string;
}
/**
 * Optional host-owned containment extension. It is invoked synchronously
 * after the circuit is quarantined and before alerts are sent. Implementations
 * may begin an asynchronous vault request, but the local guard never waits for
 * it or treats it as authorization to reopen the session.
 */
export interface CredentialRevoker {
    revoke(request: CredentialRevocationRequest): void | Promise<void>;
}
/**
 * Host-owned state shared by guards for the same reviewed identity. The key is
 * never written to Agent Canary audit events. Remote implementations should
 * make quarantine monotonic and fail closed when their backing store is down.
 */
export interface ContainmentStateStore {
    get(scopeKey: string): CircuitState | undefined;
    quarantine(scopeKey: string): boolean;
    reset(scopeKey: string): void;
}
/** Create an in-memory store for multiple guards in one trusted host process. */
export declare function createContainmentStateStore(): ContainmentStateStore;
export interface AgentGuardOptions {
    sessionId?: string;
    /** Reviewed host identity. Requires a shared stateStore to span sessions. */
    principalId?: string;
    /** Explicit shared state for the same principal across independently created guards. */
    stateStore?: ContainmentStateStore;
    /** Exact tool names that may still run after quarantine. Default: none. */
    quarantineAllow?: string[];
    /** Override only when the host has a stricter, reviewed policy. */
    classifyRisk?: (call: ToolCall) => RiskLevel;
    /** Optional JSONL destination, useful for an isolated service or test. */
    eventsFile?: string;
    /** Disable outbound/desktop notifications while retaining local audit events. */
    alert?: boolean;
    /** Optional host-owned session credential invalidation hook. */
    credentialRevoker?: CredentialRevoker;
}
export interface AgentGuard {
    readonly sessionId: string;
    readonly state: CircuitState;
    beforeToolCall(call: ToolCall): ToolDecision;
    executeToolCall<T>(call: ToolCall, operation: () => T | Promise<T>): Promise<T>;
    /** Safely answer a decoy call while tripping this session before its fake reply is created. */
    runDecoy(name: string, args?: Record<string, unknown>): ReturnType<typeof handleDecoyCall>;
    /** Detect canary tokens in agent output, tool output, or outbound payloads. */
    inspect(text: string, source?: string): CanaryToken[];
    /** Host-only action. Do not expose this method as an agent/MCP tool. */
    reset(request: ResetRequest): void;
    /** Exposed for integrations that detect a compromise outside Agent Canary's built-ins. */
    trip(input: TripInput): TripResult;
}
export declare class CanaryBlockedError extends Error {
    readonly decision: ToolDecision;
    constructor(decision: ToolDecision);
}
/** Conservative name-based baseline. Hosts can provide a stricter classifier. */
export declare function classifyToolRisk(call: ToolCall): RiskLevel;
export declare function createAgentGuard(options?: AgentGuardOptions): AgentGuard;
