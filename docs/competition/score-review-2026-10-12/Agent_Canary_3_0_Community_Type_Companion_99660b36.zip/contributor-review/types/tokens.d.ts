export interface PlantedRef {
    path: string;
    line: number;
}
export interface CanaryToken {
    token: string;
    label: string;
    createdAt: string;
    planted: PlantedRef[];
}
/** Parse one persisted record while preserving valid planted references. */
export declare function parseCanaryToken(value: unknown): CanaryToken | null;
export declare const HONEYPOT_VARS: readonly ["STRIPE_SECRET_KEY", "OPENAI_API_KEY", "GITHUB_TOKEN", "AWS_SECRET_ACCESS_KEY", "SMTP_PASSWORD", "DATABASE_URL_PASSWORD"];
export declare function mintToken(label: string): CanaryToken;
export declare function loadTokens(): CanaryToken[];
export declare function saveTokens(tokens: CanaryToken[]): void;
export declare function addTokens(added: CanaryToken[]): CanaryToken[];
export declare function generateTokens(label: string, count: number): CanaryToken[];
export declare function recordPlanted(token: CanaryToken, ref: PlantedRef): void;
/**
 * Plant canary tokens into `target`.
 * - If the file exists, a tripwire block is appended (never overwrites).
 * - If it does not exist, a honeypot file full of fake secrets is created.
 */
export declare function plantIntoFile(target: string, label: string, count: number): CanaryToken[];
export declare function findTokensInText(text: string): CanaryToken[];
export declare function scanFile(p: string): CanaryToken[];
