/**
 * Embeddable SDK for agents that do NOT speak MCP (LangChain.js, Vercel AI
 * SDK, raw provider loops). The containment guard must wrap every real tool
 * callback, so a compromise can be blocked before the callback starts:
 *
 *   const router = createGuardedToolRouter({ guard, executeRealTool });
 *   return router.dispatch({ name, args });
 */
import { handleDecoyCall } from "./decoys.js";
import { plantIntoFile, type CanaryToken } from "./tokens.js";
import { type AgentGuard, type AgentGuardOptions, type ToolCall } from "./containment.js";
export { CanaryBlockedError, classifyToolRisk, createContainmentStateStore, type AgentGuard, type AgentGuardOptions, type CircuitState, type ContainmentStateStore, type CredentialRevocationRequest, type CredentialRevoker, type ResetRequest, type RiskLevel, type ToolCall, type ToolDecision, type TripInput, type TripResult, } from "./containment.js";
export { plantIntoFile };
export type ToolFormat = "openai" | "anthropic";
export interface OpenAIToolDef {
    type: "function";
    function: {
        name: string;
        description: string;
        parameters: Record<string, unknown>;
    };
}
export interface AnthropicToolDef {
    name: string;
    description: string;
    input_schema: Record<string, unknown>;
}
/** Decoy tool schemas in the native format of the target SDK. */
export declare function decoyToolDefs(format?: ToolFormat): Array<OpenAIToolDef | AnthropicToolDef>;
/** True when the given tool name is one of our decoys. */
export declare function isDecoy(name: string): boolean;
/**
 * Invoke a decoy the model called. ALWAYS inert: fabricates a plausible fake
 * result (with a one-time trace token) and writes the attempt to the JSONL
 * audit trail / alerts. Never performs a real action.
 */
export declare function runDecoy(name: string, args?: Record<string, unknown>, guard?: AgentGuard): Promise<{
    content: Array<{
        type: "text";
        text: string;
    }>;
    isError?: boolean;
}>;
/**
 * Create one fail-closed containment boundary per agent session. Reset is a
 * host-only operation: never register it as an MCP/LLM-accessible tool.
 */
export declare function createAgentGuard(options?: AgentGuardOptions): AgentGuard;
export type DecoyToolResult = Awaited<ReturnType<typeof handleDecoyCall>>;
export type RealToolExecutor<T> = (call: ToolCall) => T | Promise<T>;
export { createSecurityToolRouter, type SecurityRouterOptions, type SecurityDecision, type SecurityAction } from './security-router.js';
export { SessionDataFlow } from './dataflow.js';
export { executePinnedJSONTool } from './network-tool.js';
export { decideAgentHook } from './agent-hook.js';
export { serveProtectedMCP } from './protected-mcp.js';
export { detectAgents, previewAgentIntegration, installAgentIntegration, restoreAgentIntegration, type AgentClient, type IntegrationState } from './agent-integrations.js';
export interface GuardedToolRouterOptions<T> {
    /** One guard per agent session. Do not share it across independent sessions. */
    guard: AgentGuard;
    /** The only callback path for non-decoy tools routed through this helper. */
    executeRealTool: RealToolExecutor<T>;
}
export interface GuardedToolRouter<T> {
    readonly guard: AgentGuard;
    /** Route decoys to their inert reply; route every other call through the guard. */
    dispatch(call: ToolCall): Promise<T | DecoyToolResult>;
}
/**
 * Build one safe dispatch path for a non-MCP agent integration.
 *
 * Decoys are always answered by `guard.runDecoy()` and never reach the real
 * callback. All other calls go through `guard.executeToolCall()`, so a
 * quarantined session cannot accidentally run the host callback.
 */
export declare function createGuardedToolRouter<T>(options: GuardedToolRouterOptions<T>): GuardedToolRouter<T>;
/** Find exact matches for registered tokens in inspected text. A match alone does not prove malicious intent. */
export declare function scanCanary(text: string): CanaryToken[];
export interface TokenGuard {
    /**
     * Inspect a piece of agent output (final answers, tool args, tool results,
     * outbound payloads). Returns the leaked tokens found; each hit is also
     * written to the audit trail and alerts (disable with { alert: false }).
     */
    inspect(text: string, source?: string): CanaryToken[];
}
export declare function createTokenGuard(opts?: {
    alert?: boolean;
    session?: AgentGuard;
}): TokenGuard;
export { createAIProvider, previewAnalysis, PROVIDER_PRESETS } from './ai/provider.js';
export type { AIProvider, ProviderConfig, ModelInfo, ConnectionResult, SecurityAnalysisRequest, SecurityAnalysisResult, SecurityEvidence } from './ai/types.js';
export { createRiskPolicyRouter, PolicyBlockedError } from './risk-policy.js';
export type { ProtectionMode, ToolRisk, ToolOperation, RiskToolDescriptor, RiskPolicyOptions, PolicyDecision } from './risk-policy.js';
export { createFileContainmentStateStore } from './file-state-store.js';
export { createTrustedExecutionGateway, GatewayDeniedError, type GatewayOptions, type GatewayFile, type GatewayCommand } from './runtime/gateway.js';
export { EvidenceRecorder, canonicalJSON, evidenceDigest, validateEvidence, verifyEvidenceChain, type SecurityEvidenceEvent } from './runtime/evidence.js';
export { HoneypotRuntime, planAdaptiveDecoys, type DecoyKind, type DecoyInteraction } from './runtime/honeypot.js';
export { DataFlowTracker } from './runtime/dataflow.js';
