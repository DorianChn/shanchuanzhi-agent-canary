export interface SelfTestCheck {
    name: "safe_call" | "decoy_quarantine" | "blocked_callback" | "audit_order";
    passed: boolean;
}
export interface SelfTestResult {
    passed: boolean;
    checks: SelfTestCheck[];
}
/**
 * Exercise the containment path entirely in a temporary directory.
 *
 * It never reads or writes the user's config, token registry, event log, or
 * webhook. The decoy is inspected through `beforeToolCall` rather than run,
 * so no trace token is minted during this installation check.
 */
export declare function runSelfTest(): Promise<SelfTestResult>;
