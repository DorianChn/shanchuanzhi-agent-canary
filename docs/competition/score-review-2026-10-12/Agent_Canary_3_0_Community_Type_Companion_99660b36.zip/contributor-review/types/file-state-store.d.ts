import type { ContainmentStateStore } from './containment.js';
/** Opt-in local persistence for trusted hosts. This is not a distributed database. */
export declare function createFileContainmentStateStore(file: string, options?: {
    initialize?: boolean;
    maxScopes?: number;
}): ContainmentStateStore;
