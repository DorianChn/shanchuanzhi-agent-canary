import { type RiskPolicyOptions, type PolicyDecision } from './risk-policy.js';
import { type AgentGuard, type ToolCall } from './containment.js';
import type { AIProvider, SecurityAnalysisResult } from './ai/types.js';
export type SecurityAction = 'ALLOW' | 'DENY' | 'REQUIRE_APPROVAL' | 'SANDBOX' | 'OBSERVE_ONLY';
export interface SecurityDecision {
    action: SecurityAction;
    reason: string;
    risks: PolicyDecision['risks'];
    mode: PolicyDecision['mode'];
    coverage: 'REGISTERED_HOST_CALLBACKS_ONLY';
}
export interface SecurityRouterOptions<T> extends RiskPolicyOptions {
    guard: AgentGuard;
    executeRealTool: (call: ToolCall, context: {
        signal: AbortSignal;
    }) => T | Promise<T>;
    /** Optional stronger execution path, supplied by trusted host, not AI. */
    executeSandboxTool?: (call: ToolCall, context: {
        signal: AbortSignal;
    }) => T | Promise<T>;
    provider?: AIProvider;
    cloudConsent?: boolean;
    reviewTimeoutMs?: number;
    callbackTimeoutMs?: number;
    /** Real FS hosts should enable this. Virtual fixture hosts leave it false. */
    verifyRealPaths?: boolean;
    dataflowTtlMs?: number;
    onReview?: (record: {
        tool: string;
        result: SecurityAnalysisResult | null;
        status: string;
        durationMs: number;
    }) => void;
}
export declare function createSecurityToolRouter<T>(options: SecurityRouterOptions<T>): {
    decide(call: ToolCall): Promise<SecurityDecision>;
    dataflow: () => {
        label: string;
        expires: number;
        hash: string;
    }[];
    reviews: () => {
        tool: string;
        result: SecurityAnalysisResult | null;
        status: string;
        durationMs: number;
    }[];
    mode: import("./risk-policy.js").ProtectionMode;
    guard: AgentGuard;
    dispatch(call: ToolCall): Promise<{
        content: Array<{
            type: "text";
            text: string;
        }>;
        isError?: boolean;
    } | T>;
    approve(requestId: string, acknowledgedBy: string): Promise<{
        content: Array<{
            type: "text";
            text: string;
        }>;
        isError?: boolean;
    } | T>;
    pendingApprovals(): {
        requestId: string;
        tool: string;
        risks: import("./risk-policy.js").ToolRisk[];
        reason: string;
        expiresAt: number;
    }[];
    inspectPolicy(call: ToolCall): PolicyDecision;
    denyApproval(requestId: string): void;
};
