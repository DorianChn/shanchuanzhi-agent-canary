/** Official hook protocol adapter. Input fixtures verified; actual client activation is separate. */
export declare function decideAgentHook(client: 'claude' | 'cursor', workspaceRoot: string, stateDirectory: string, input: Record<string, unknown>): Promise<{
    hookSpecificOutput: {
        hookEventName: string;
        permissionDecision: "allow" | "deny" | "ask";
        permissionDecisionReason: string;
    };
    permission?: undefined;
    user_message?: undefined;
    agent_message?: undefined;
} | {
    permission: "allow" | "deny" | "ask";
    user_message: string;
    agent_message: string;
    hookSpecificOutput?: undefined;
}>;
